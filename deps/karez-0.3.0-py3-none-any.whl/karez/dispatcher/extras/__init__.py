from . import default

PLUGINS = dict(
    default=default.Dispatcher,
)