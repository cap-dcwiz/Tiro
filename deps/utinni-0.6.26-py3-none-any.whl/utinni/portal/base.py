from pathlib import Path

import typer
import uvicorn
from dynaconf import Dynaconf
from fastapi import APIRouter, FastAPI

from .utils import import_cookbook
from .. import Context
from ..pump import WrappedDataPump
from ..utils import chainable


class PortalAPIRouterBase(APIRouter):
    def __init__(self, *args, **kwargs):
        super(PortalAPIRouterBase, self).__init__(*args, **kwargs)
        self.config = None
        self.cookbooks = {}

    @chainable
    def setup(self, config, cookbooks=None, cookbook_locations=()):
        self.cookbooks = cookbooks or {}
        for loc in cookbook_locations:
            name, cb = import_cookbook(loc)
            self.cookbooks[name] = self.cookbooks.get(name, [])
            self.cookbooks[name].append(cb)
        self.config = config

    @chainable
    def add_cookbooks(self, cookbooks):
        self.cookbooks |= cookbooks

    def prepare_context(self, context_name, add_wrapped_pump=True):
        context = Context()
        if add_wrapped_pump:
            context.add_pump("portal_wrap", WrappedDataPump())
        for cookbook in self.cookbooks[context_name]:
            cookbook(context, self.config)
        context.bind(**self.config.on_request.get("base", {}))
        config = self.config.on_request.get(context_name, None)
        if config is None:
            config = self.config.on_request.get("fallback", None)
        if config is None:
            config = {}
        return context.bind(**config)

    def make_entry(self):
        def entry(cookbook: list[str],
                  config: list[Path] = typer.Option(None, "--conf", "-c"),
                  host: str = typer.Option("127.0.0.1", "--host", "-h"),
                  port: int = typer.Option(8000, "--port", "-p"),
                  root_path: str = typer.Option("", "--root_path", "-r")
                  ):
            conf = Dynaconf(settings_files=config or ["./config.toml"])
            self.setup(conf)
            cookbooks = {}
            for loc in cookbook:
                name, cb = import_cookbook(loc)
                cookbooks[name] = cookbooks.get(name, [])
                cookbooks[name].append(cb)
            self.add_cookbooks(cookbooks)
            fastapi_app = FastAPI()
            fastapi_app.include_router(self)
            uvicorn.run(fastapi_app, host=host, port=port, root_path=root_path)

        return entry
