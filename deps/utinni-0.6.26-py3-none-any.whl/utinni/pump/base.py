from abc import ABC, abstractmethod
from datetime import datetime, timedelta
from numbers import Number

from numpy import inf
from pytz import UTC

from ..config import Configurable
from ..types import ValueType
from ..utils import chainable


class DataPump(Configurable, ABC):
    # PreProcessor: Type[PreProcessorBase] = NullPreProcessor

    def __init__(self, *args, **kwargs):
        super(DataPump, self).__init__(*args, **kwargs)
        self.context = None
        self.name = None

    @chainable
    def set_context(self, context):
        self.context = context

    @chainable
    def set_name(self, name: str):
        self.name = name

    @abstractmethod
    def gen_table(self, *args, **kwargs):
        pass

    @abstractmethod
    def get_data(self, table, fields) -> ValueType:
        pass

    def all_values_for_tag(self, tag: str):
        return None

    def __repr__(self):
        return f"{self.name}_pump({self.__class__.__name__})"


class TimeSeriesDataPump(DataPump, ABC):
    def config_items(self):
        yield from super(TimeSeriesDataPump, self).config_items()
        yield "start", None, None
        yield "step", None, None
        yield "stop", None, None

        yield "interpolate", None, None
        yield "interpolate_limit", None, None
        yield "interpolate_value_range", (-inf, inf), None
        yield "interpolate_fill_na", 0, "Can be a number, False, bfill or ffill"
        yield ("interpolate_kwargs",
               dict(method="spline", order=3,
                    limit_area="inside"),
               "Approach and kwargs for interpolation")

    def extract_config(self, config: dict[str, ...]) -> dict[str, ...]:
        start = self.new_or_current_config(config, "start")
        stop = config.get("stop", datetime.utcnow())
        step = self.new_or_current_config(config, "step")
        if isinstance(step, Number):
            step = timedelta(seconds=float(step))
        if isinstance(stop, timedelta):
            stop = start + stop
        if isinstance(start, timedelta):
            start = stop + start
        if start and start.tzinfo is None:
            start = start.replace(tzinfo=UTC)
        if stop and stop.tzinfo is None:
            stop = stop.replace(tzinfo=UTC)

        interpolate = self.new_or_current_config(config, "interpolate")
        interpolate_limit = self.new_or_current_config(config, "interpolate_limit")
        interpolate_value_range = self.new_or_current_config(config, "interpolate_value_range")
        interpolate_fill_na = self.new_or_current_config(config, "interpolate_fill_na")
        interpolate_kwargs = self.new_or_current_config(config, "interpolate_kwargs")
        if isinstance(interpolate_limit, str) and interpolate_limit.endswith("s"):
            interpolate_limit = timedelta(seconds=float(interpolate_limit[:-1]))
        if isinstance(interpolate_limit, timedelta) and step:
            if isinstance(step, str):
                if "mo" in step or "MS" in step:
                    _step = timedelta(days=30 * float(step[:-2]))
                elif "M" in step:
                    _step = timedelta(days=30 * float(step[:-1]))
                else:
                    raise RuntimeError(f"Unrecognised step: {step}")
                interpolate_limit = interpolate_limit // _step
            elif isinstance(step, Number):
                interpolate_limit = interpolate_limit.total_seconds() // step
            else:
                interpolate_limit = interpolate_limit // step

        return dict(start=start,
                    step=step,
                    stop=stop,
                    interpolate=interpolate,
                    interpolate_limit=interpolate_limit,
                    interpolate_value_range=interpolate_value_range,
                    interpolate_fill_na=interpolate_fill_na,
                    interpolate_kwargs=interpolate_kwargs,
                    )
