from functools import wraps
from typing import TypeVar, Union

from numpy import inf
from pandas import Series, DataFrame

T = TypeVar("T")


def chainable(func):
    @wraps(func)
    def wrapped(self: T, *args, **kwargs) -> T:
        func(self, *args, **kwargs)
        return self

    wrapped.__chainable__ = True
    return wrapped


def easy_interpolate(df: Union[DataFrame, Series],
                     min_value: float = -inf,
                     max_value: float = inf,
                     **kwargs) -> Union[DataFrame, Series]:
    kwargs["limit_direction"] = kwargs.get("limit_direction", "both")
    try:
        df = df.interpolate(method="quadratic", **kwargs)
    except ValueError:
        pass
    df.interpolate(method="linear", inplace=True, **kwargs)
    return df.clip(min_value, max_value)




