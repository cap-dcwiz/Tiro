from functools import partial

from .config import Configurable
from .runtime.runtime import Runtime
from .utils import chainable


class Context:
    def __init__(self, clients=None, **kwargs):
        self.runtime = Runtime(self)
        self.pumps = dict()
        self.current_config = {}
        self.configurable_instances: set[Configurable] = set()
        self.transform_libraries = {}
        self.bind(**kwargs)
        self.clients = clients or {}

    def add_client(self, overwrite=False, **clients):
        for key, client in clients.items():
            if key not in self.clients or overwrite:
                self.clients[key] = client

    @chainable
    def bind(self, **kwargs):
        for instance in self.configurable_instances:
            instance.update_config(**kwargs)
        self.current_config |= kwargs
        self.runtime.mark_dirty()

    def config_options(self):
        return {ins: list(ins.config_items()) for ins in self.configurable_instances}

    @chainable
    def add_pump(self, name, pump: Configurable):
        self.pumps[name] = pump.set_context(self).set_name(name)
        pump.update_config(**self.current_config)
        self.configurable_instances.add(pump)
        setattr(self, f"{name}_table", partial(self.table, name))
        setattr(self, f"{name}_pump", pump)

    @chainable
    def del_pump(self, name):
        pump = self.pumps[name]
        del self.pumps[name]
        self.configurable_instances.remove(pump)
        delattr(self, f"{name}_table")
        delattr(self, f"{name}_pump")

    def table(self, pump_name, *args, **kwargs):
        return self.pumps[pump_name].gen_table(*args, **kwargs)

    def create_transform_library(self, cls, *args, **kwargs):
        if cls not in self.transform_libraries:
            self.transform_libraries[cls] = cls(*args, **kwargs)
        return self.transform_libraries[cls]

    def __getattr__(self, item):
        if self.runtime.has_define(item):
            return self.runtime.get_define(item)
        else:
            res = getattr(self.runtime, item)
            if getattr(res, "__chainable__", False):

                def wrapped(*args, **kwargs):
                    res(*args, **kwargs)
                    return self

                return wrapped
            else:
                return res

    def clear(self):
        self.clear_def()
        for name in self.pumps:
            delattr(self, f"{name}_table")
            delattr(self, f"{name}_pump")
        self.pumps.clear()
        self.configurable_instances.clear()
        self.transform_libraries.clear()
        self.clients.clear()
        self.runtime = None

    def __iter__(self):
        yield from self.runtime
