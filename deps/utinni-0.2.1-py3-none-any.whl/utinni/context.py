from functools import partial

from .config import Configurable
from .runtime.runtime import Runtime
from .utils import chainable


class Context:
    def __init__(self, **kwargs):
        self.runtime = Runtime(self)
        self.pumps = dict()
        self.current_config = {}
        self.configurable_instances: set[Configurable] = set()
        self.bind(**kwargs)

    @chainable
    def bind(self, **kwargs):
        for instance in self.configurable_instances:
            instance.update_config(**kwargs)
        self.current_config |= kwargs
        self.runtime.mark_dirty()

    def config_options(self):
        return {ins: list(ins.config_items()) for ins in self.configurable_instances}

    @chainable
    def add_pump(self, name, pump: Configurable):
        self.pumps[name] = pump.set_context(self).set_name(name)
        pump.update_config(**self.current_config)
        self.configurable_instances.add(pump)
        setattr(self, f"{name}_table", partial(self.table, name))
        setattr(self, f"{name}_pump", pump)

    @chainable
    def del_pump(self, name):
        pump = self.pumps[name]
        del self.pumps[name]
        self.configurable_instances.remove(pump)
        delattr(self, f"{name}_table")
        delattr(self, f"{name}_pump")

    def table(self, pump_name, *args, **kwargs):
        return self.pumps[pump_name].gen_table(*args, **kwargs)

    def __getattr__(self, item):
        if self.runtime.has_define(item):
            return self.runtime.get_define(item)
        else:
            return getattr(self.runtime, item)


