from abc import ABC
from datetime import datetime, timedelta
from typing import Union

import pandas as pd

from utinni.types import ValueType, DFSType, Dim0ValueType, Dim1ValueType, Dim2ValueType, Dim3ValueType
from utinni.utils import easy_interpolate


class PreProcessorBase(ABC):
    def preprocess(self, value: ValueType, dim: int, config) -> ValueType:
        preprocessor = getattr(self, f"preprocess_dim_{dim}", None)
        if preprocessor:
            return preprocessor(value, config)
        else:
            raise NotImplementedError

    def preprocess_dim_0(self, value: Dim0ValueType, config) -> Dim0ValueType:
        return value

    def preprocess_dim_1(self, value: Dim1ValueType, config) -> Dim1ValueType:
        return value

    def preprocess_dim_2(self, value: Dim2ValueType, config) -> Dim2ValueType:
        return value

    def preprocess_dim_3(self, value: Dim3ValueType, config) -> Dim3ValueType:
        return {k: self.preprocess_dim_2(v, config) for k, v in value.items()}


class NullPreProcessor(PreProcessorBase):
    pass


class PreProcessorForTSTable(PreProcessorBase):
    def align_time_index(self, df: DFSType,
                         start: datetime,
                         stop: datetime,
                         step: timedelta) -> DFSType:
        idx = df.index
        idx_min = idx.min()
        idx_max = idx.max()
        # idx_min = idx_min.astimezone(pytz.UTC)
        # idx_max = idx_max.astimezone(pytz.UTC)
        if idx_min > start:
            idx = idx.union(pd.date_range(start, idx_min, freq=step))
        if idx_max < stop:
            idx = idx.union(pd.date_range(idx_max, stop, freq=step))

        df = df.reindex(idx)
        df = df.sort_index().resample(step, origin="epoch").last()
        return df

    def preprocess_dim_1or2(self,
                            value: Union[Dim1ValueType, Dim2ValueType],
                            config) -> Union[Dim1ValueType, Dim2ValueType]:
        value = self.align_time_index(value, config.start, config.stop, config.step)
        if config.interpolate and config.interpolate_limit > 0:
            value = easy_interpolate(value,
                                     limit_direction="both",
                                     limit=config.interpolate_limit,
                                     min_value=config.interpolate_value_range[0],
                                     max_value=config.interpolate_value_range[1],
                                     )
            value.fillna(0, inplace=True)
        return value

    preprocess_dim_1 = preprocess_dim_1or2
    preprocess_dim_2 = preprocess_dim_1or2
