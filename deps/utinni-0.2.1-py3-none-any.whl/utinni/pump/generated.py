from abc import ABC, abstractmethod
from datetime import datetime, timedelta

import numpy as np
import pandas as pd

from .base import TimeSeriesDataPump
from ..table.table import TimeSeriesPrimaryTable


def _timeshift_by_epoch(dt: datetime, step: timedelta):
    step_seconds = step.total_seconds()
    ts = dt.timestamp()
    return timedelta(seconds=ts - ts // step_seconds * step_seconds)


class GeneratedTSDataPump(TimeSeriesDataPump, ABC):
    def gen_index(self, start, stop, step):
        if isinstance(step, timedelta):
            start -= _timeshift_by_epoch(start, step)
            stop -= _timeshift_by_epoch(stop, step)
        return pd.date_range(start, stop, freq=step)

    @abstractmethod
    def gen_values(self, table, size):
        raise NotImplementedError

    def get_data(self, table: TimeSeriesPrimaryTable, fields):
        index = self.gen_index(self.config.start, self.config.stop, self.config.step)
        if fields:
            data = []
            for column in fields:
                values, dtype = self.gen_values(table, size=len(index))
                series = pd.Series(data=values,
                                   index=index,
                                   dtype=dtype,
                                   name=column)
                data.append(series)
            df = pd.concat(data, axis=1)
        else:
            values, dtype = self.gen_values(table, size=len(index))
            df = pd.Series(data=values,
                           index=index,
                           dtype=dtype)
        return df


class ConstantTSDataPump(GeneratedTSDataPump):
    def gen_table(self, value, fields=None):
        return TimeSeriesPrimaryTable(context=self.context,
                                      pump=self,
                                      fields=fields,
                                      meta=dict(fixed_value=value))

    def gen_values(self, table, size):
        value = table.meta["fixed_value"]
        return value, type(value)


class RandomTSDataPump(GeneratedTSDataPump):
    def gen_table(self, rand_func, rand_args, fields=None):
        return TimeSeriesPrimaryTable(context=self.context,
                                      pump=self,
                                      fields=fields,
                                      meta=dict(rand_func=rand_func,
                                                rand_args=rand_args))

    def gen_values(self, table, size):
        rand_func = table.meta["rand_func"]
        rand_args = table.meta["rand_args"]
        rng = np.random.default_rng()
        func = getattr(rng, rand_func)
        value = func(size=size, **rand_args)
        return value, value.dtype
