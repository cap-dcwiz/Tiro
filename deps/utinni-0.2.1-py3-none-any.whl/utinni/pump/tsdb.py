import logging
from datetime import timedelta, datetime
from numbers import Number
from typing import Union, TypeAlias

from influxdb_client import InfluxDBClient
from pandas import DataFrame

from .base import TimeSeriesDataPump
from ..table.table import TimeSeriesPrimaryTable
from ..types import Dim3ValueType, Dim2ValueType, ValueType

QUERY_FLUX_HEAD = """
from(bucket: _bucket)
  |> range(start: _start, stop: _stop)
  |> filter(fn: (r) => r["_measurement"] == _measurement)"""

QUERY_FLUX_TAIL = """
  |> aggregateWindow(every: {time_step}, fn: {agg_fn}, createEmpty: false, timeSrc: "_start")
  |> keep(columns: _columns)
  |> pivot(columnKey: _column_key, rowKey: ["_time"], valueColumn: "_value")"""

STEP_REPLACE_MAP = {
    "MS": "mo",
    "M": "mo",
}


def _append_filter(flux_str, field, candidates):
    if candidates:
        _filter = " or ".join(f'r["{field}"] == "{c}"' for c in candidates)
        return flux_str + f"\n  |> filter(fn: (r) => {_filter})"
    else:
        return flux_str


FilterValueType = Union[str, Number]
FilterKeyType = str
FilterType: TypeAlias = dict[FilterKeyType, Union[FilterValueType, list[FilterValueType]]]


class InfluxDBDataPump(TimeSeriesDataPump):
    def __init__(self, *args, url, token, org, bucket, measurement, **kwargs):
        super(InfluxDBDataPump, self).__init__(*args, **kwargs)
        self.client: InfluxDBClient = InfluxDBClient(url=url, token=token, org=org, verify_ssl=False)
        self.bucket: str = bucket
        self.measurement: str = measurement
        self.query_cache = {}

    def gen_table(self, field=None, column=None, agg_fn="mean", **filters):
        return TimeSeriesPrimaryTable(context=self.context,
                                      pump=self,
                                      fields=field,
                                      meta=dict(column=column,
                                                filters=filters,
                                                agg_fn=agg_fn))

    def __getitem__(self, item):
        table = self.query_cache.get(item, self.default_query(item))
        self.query_cache[table] = table
        return table

    def default_query(self, item):
        return None

    def get_data(self, table: TimeSeriesPrimaryTable, fields) -> ValueType:
        return self.query(start=self.config.start,
                          stop=self.config.stop,
                          step=self.config.step,
                          field=fields,
                          filters=table.meta["filters"],
                          column=table.meta["column"],
                          agg_fn=table.meta["agg_fn"])

    def post_process_query(self, data):
        if isinstance(data, DataFrame):
            columns = [x for x in ("table", "result", "_field") if x in data]
            return data.drop(columns=columns).set_index("_time")
        else:
            return {k: self.post_process_query(v) for k, v in data.items()}

    def query(self,
              start: datetime,
              stop: datetime,
              step: Union[timedelta, str, int, float],
              field: Union[str, list[str]] = None,
              filters: FilterType = None,
              column: str = None,
              agg_fn: str = "mean"
              ) -> Union[Dim2ValueType, Dim3ValueType]:
        """
        Query data from influxdb
        :param start:
        :param stop:
        :param step:
        :param config: configurations
        :param field: the field that will be the value of generated table.
                      Can be a list, in which case a dict of fields and DataFrames will be returned.
        :param filters: dict of tag_name and choices
        :param column: Tag name that will be used as table columns
        :param agg_fn:
        :return:
        """
        flux_str = QUERY_FLUX_HEAD

        if field:
            if isinstance(field, list):
                flux_str = _append_filter(flux_str, "_field", list(field))
            elif isinstance(field, str):
                flux_str = _append_filter(flux_str, "_field", [field])
            else:
                raise TypeError("field must be str or list[str]")

        if filters:
            for key, values in filters.items():
                if isinstance(values, list):
                    values = list(values)
                else:
                    values = [values]
                flux_str = _append_filter(flux_str, key, values)

        flux_str = flux_str + QUERY_FLUX_TAIL

        columns = ["_time", "_field", "_value"]
        if column:
            columns.append(column)
            column_key = column
        else:
            column_key = "_field"

        if isinstance(step, str):
            for k, v in STEP_REPLACE_MAP.items():
                if k in step:
                    step = step.replace(k, v)
        elif isinstance(step, timedelta):
            step = f"{int(step.total_seconds())}s"
        else:
            step = f"{int(step)}s"

        flux_str = flux_str.format(agg_fn=agg_fn, time_step=step)
        logging.debug(f"INFLUXDB QUERY: {flux_str} \n"
                      f"start={start} \n"
                      f"stop={stop} \n"
                      f"step={step} \n"
                      f"bucket={self.bucket} \n"
                      f"measurement={self.measurement}")
        response = self.client.query_api().query_data_frame(
            flux_str,
            params={
                "_bucket": self.bucket,
                "_start": start,
                "_stop": stop,
                "_measurement": self.measurement,
                "_columns": columns,
                "_column_key": [column_key]
            })

        if isinstance(response, list):
            ret = {}
            for r in response:
                ret.update({k: g for k, g in r.groupby("_field")})
        else:
            if response.empty:
                raise RuntimeError("Cannot find any data in TSDB.")
            if response.table.nunique() > 1:
                ret = {k: g for k, g in response.groupby("_field")}
            elif "_field" in response and (not field or isinstance(field, list)):
                ret = {response.iloc[0]["_field"]: response}
            elif isinstance(field, str):
                ret = {field: response}
            else:
                ret = response
        return self.post_process_query(ret)
