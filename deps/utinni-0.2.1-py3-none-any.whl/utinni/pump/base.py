from abc import ABC, abstractmethod
from datetime import datetime, timedelta
from typing import Type

from numpy import inf
from pytz import UTC

from utinni.pump.preprocess import PreProcessorBase, NullPreProcessor, PreProcessorForTSTable
from ..config import Configurable
from ..types import ValueType
from ..utils import chainable, guess_dim


class DataPump(Configurable, ABC):
    PreProcessor: Type[PreProcessorBase] = NullPreProcessor

    def __init__(self, *args, **kwargs):
        super(DataPump, self).__init__(*args, **kwargs)
        self.context = None
        self.name = None
        self.preprocessor = self.PreProcessor()

    @chainable
    def set_context(self, context):
        self.context = context

    @chainable
    def set_name(self, name: str):
        self.name = name

    @abstractmethod
    def gen_table(self, *args, **kwargs):
        pass

    @abstractmethod
    def get_data(self, table, fields) -> ValueType:
        pass

    def get_data_and_preprocess(self, table, fields):
        data = self.get_data(table, fields)
        dim = guess_dim(data)
        return self.preprocessor.preprocess(data, dim, self.config)

    def all_values_for_tag(self, tag: str):
        return None

    def __repr__(self):
        return f"{self.name}_pump({self.__class__.__name__})"


class TimeSeriesDataPump(DataPump, ABC):
    PreProcessor = PreProcessorForTSTable

    def config_items(self):
        yield from super(TimeSeriesDataPump, self).config_items()
        yield "start", None, None
        yield "step", None, None
        yield "stop", None, None

        yield "interpolate", None, None
        yield "interpolate_limit", None, None
        yield "interpolate_value_range", (-inf, inf), None

    def extract_config(self, config: dict[str, ...]) -> dict[str, ...]:
        start = self.new_or_current_config(config, "start")
        stop = config.get("stop", datetime.utcnow())
        step = self.new_or_current_config(config, "step")
        if isinstance(stop, timedelta):
            stop = start + stop
        if isinstance(start, timedelta):
            start = stop + start
        if start and start.tzinfo is None:
            start = start.replace(tzinfo=UTC)
        if stop and stop.tzinfo is None:
            stop = stop.replace(tzinfo=UTC)

        interpolate = self.new_or_current_config(config, "interpolate")
        interpolate_limit = self.new_or_current_config(config, "interpolate_limit")
        interpolate_value_range = self.new_or_current_config(config, "interpolate_value_range")
        if isinstance(interpolate_limit, timedelta) and step:
            interpolate_limit = interpolate_limit // step

        return dict(start=start,
                    step=step,
                    stop=stop,
                    interpolate=interpolate,
                    interpolate_limit=interpolate_limit,
                    interpolate_value_range=interpolate_value_range,
                    )
