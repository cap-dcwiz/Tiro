import logging
from functools import partial
from typing import Callable, Union

import numpy as np
import pandas as pd
from itertools import chain
from pandas import Series

from ..abc import TableABC, SingletonBase
from ..types import ValueType, Dim0ValueType, Dim1ValueType, Dim2ValueType
from ..utils import easy_interpolate


class Transform:
    def __init__(self, method, dependency_method=None):
        self.method = method
        self.dependency_method = dependency_method or self.default_dependency_method

    def record_dependency(self, method):
        self.dependency_method = method
        return method

    def default_dependency_method(self, *args, **kwargs):
        for arg in chain(args, kwargs.values()):
            if isinstance(arg, TableABC):
                yield arg, "ALL", "ALL"

    def partial(self, *args, **kwargs):
        method = partial(self.method, *args, **kwargs)
        dep_method = partial(self.dependency_method, *args, **kwargs)
        return self.__class__(method, dep_method)

    def calculate_field_dependencies(self, *args, **kwargs):
        return self.dependency_method(*args, **kwargs)


class TransformOverValues(Transform):
    def __call__(self, *args, **kwargs):
        args = [arg.value if isinstance(arg, TableABC) else arg for arg in args]
        kwargs = {k: v.value if isinstance(v, TableABC) else v for k, v in kwargs.items()}
        return self.method(*args, **kwargs)


class TransformOverTables(Transform):
    def __call__(self, *args, **kwargs):
        return self.method(*args, **kwargs)


tf_over_values = TransformOverValues
tf_over_tables = TransformOverTables


class TransformLibrary(SingletonBase):
    def __getitem__(self, item):
        func = getattr(self, f"tf_{item}", None)
        if func:
            return func.partial(self)

    @staticmethod
    def gen_bin_op(s):
        def _get_real_op(value):
            if isinstance(value, Dim0ValueType):
                return getattr(value, f"__{s}__")
            elif isinstance(value, Dim1ValueType):
                return partial(getattr(value, s))
            elif isinstance(value, Dim2ValueType):
                return partial(getattr(value, s))
            elif isinstance(value, dict):  # Dim3ValueType
                # TODO: Untested
                return lambda other: {k: getattr(v, s)(other) for k, v in value.items()}

        def _tf(value, other):
            return _get_real_op(value)(other)

        def op(self, other):
            return self.apply_tf(_tf, other)

        def rop(self, other):
            return self.apply_tf(_tf, other)

        return op, rop

    @staticmethod
    def gen_func(func: Callable[..., ValueType]):
        def _get_real_func(value):
            if isinstance(value, Dim0ValueType):
                return func
            elif isinstance(value, Dim1ValueType):
                return func
            elif isinstance(value, Dim2ValueType):
                return func
            elif isinstance(value, dict):  # Dim3ValueType
                # TODO: Untested
                return lambda _, *args, **kwargs: {k: func(v, *args, **kwargs) for k, v in value.items()}

        def _tf(value, *args, **kwargs):
            return _get_real_func(value)(value, *args, **kwargs)

        def op(self, *args, **kwargs):
            return self.apply_tf(_tf, *args, **kwargs)

        return op

    @classmethod
    def gen_func_along_axes(cls, func: Callable[..., ValueType], *axes):
        return [cls.gen_func(partial(func, axis=axis)) for axis in axes]

    @classmethod
    def install_special_and_predefined_methods(cls, table_cls):
        table_cls.__add__, table_cls.__radd__ = cls.gen_bin_op("add")
        table_cls.__mul__, table_cls.__rmul__ = cls.gen_bin_op("mul")
        table_cls.__sub__, table_cls.__rsub__ = cls.gen_bin_op("sub")
        table_cls.__truediv__, table_cls.__rtruediv__ = cls.gen_bin_op("truediv")
        table_cls.__floordiv__, table_cls.__rfloordiv__ = cls.gen_bin_op("floordiv")
        table_cls.__pow__ = cls.gen_func(pow)
        table_cls.__abs__ = cls.gen_func(abs)
        table_cls.__neg__ = cls.gen_func(lambda x: -x)

    @tf_over_tables
    def tf_ascent(self, table: TableABC, name: str = None) -> ValueType:
        value = table.value
        if isinstance(value, Dim0ValueType):
            result = Series([value], name=name or table.name)
        elif isinstance(value, Dim1ValueType):
            result = value.to_frame(name=name or table.name or value.name)
        elif isinstance(value, Dim2ValueType):
            result = {(name or table.name): value}
        else:
            raise ValueError("3D value cannot be ascended.")
        return result

    @tf_ascent.record_dependency
    def _(self, table, name=None):
        yield table, "ALL", name or table.name or "ALL"

    @tf_over_values
    def tf_aggregate(self, *values: ValueType) -> ValueType:
        if isinstance(values[0], Dim0ValueType):
            result = Series(values)
        elif isinstance(values[0], Dim1ValueType):
            result = pd.concat(values, axis=1)
        elif isinstance(values[0], Dim2ValueType):
            result = {v.name: v for v in values}
        else:
            raise ValueError("Cannot aggregate 3D value.")
        return result

    @tf_aggregate.record_dependency
    def _(self, *tables):
        for table in tables:
            if table.name:
                yield table, table.name, table.name
            else:
                yield table, "ALL", "ALL"

    @tf_over_values
    def tf_concat(self, *values: ValueType) -> ValueType:
        if isinstance(values[0], Dim0ValueType):
            raise ValueError("Cannot concat 1D values")
        elif isinstance(values[0], Dim1ValueType):
            result = pd.concat(values, axis=0)
        elif isinstance(values[0], Dim2ValueType):
            result = pd.concat(values, axis=1)
        elif isinstance(values[0], dict):
            result = {}
            for v in values:
                result |= v
        else:
            raise ValueError
        return result

    @tf_concat.record_dependency
    def _(self, *tables):
        for table in tables:
            yield table, "ALL", "ALL"

    @tf_over_values
    def tf_extract(self, value: ValueType, name: Union[str, list[str]]) -> ValueType:
        if isinstance(value, Dim0ValueType):
            raise ValueError("Cannot extract from 1D value.")
        elif isinstance(value, Dim1ValueType):
            if isinstance(name, list):
                result = value[value.index.isin(name)]
            else:
                result = value[name]
        elif isinstance(value, Dim2ValueType):
            result = value[name]
        elif isinstance(value, dict):
            if isinstance(name, list):
                result = {k: v for k, v in value.items() if k in name}
            else:
                result = value[name]
        else:
            raise ValueError
        return result

    @tf_extract.record_dependency
    def _(self, table, name):
        if isinstance(name, str):
            yield table, name, "ALL"
        else:
            for item in name:
                yield table, item, item

    @tf_over_values
    def tf_remove_zeros(self, data):
        return data.replace(0, np.NAN)

    @tf_over_values
    def tf_dropna(self, data, include_inf=False, **kwargs):
        if include_inf:
            data = data.replace([np.inf, -np.inf], np.nan)
        return data.dropna(**kwargs)

    @tf_over_values
    def tf_count_nz(self, data, **kwargs):
        return data.fillna(0).astype(bool).sum(**kwargs)

    @tf_over_values
    def tf_period_total(self, data):
        total_second = (data.index.max() - data.index.min()).total_seconds()
        return data.mean(axis=0) * total_second

    @tf_over_values
    def tf_filter_columns(self, data, func):
        if isinstance(data, Dim2ValueType):
            return data[[c for c in data.columns if func(c)]]
        elif isinstance(data, dict):
            return {k: v[[c for c in v.columns if func(c)]] for k, v in data.items()}
        else:
            raise ValueError(f"Unexpected value type: {type(data)}")

    @tf_over_values
    def tf_iloc(self, data, index):
        if isinstance(data, Dim1ValueType) or isinstance(data, Dim2ValueType):
            return data.iloc[index]
        else:
            raise ValueError(f"iloc not support on value type: {type(data)}")


class TransformLibraryForTSTable(TransformLibrary):
    # @classmethod
    # def install_special_and_predefined_methods(cls, table_cls):
    #     super(TransformLibraryForTSTable, cls).install_special_and_predefined_methods(table_cls)
    #     table_cls.period_sum, table_cls.sum = \
    #         cls.gen_func_along_axes(DataFrame.sum, 0, 1)
    #     table_cls.period_count, table_cls.count = \
    #         cls.gen_func_along_axes(DataFrame.count, 0, 1)
    #     table_cls.period_mean, table_cls.mean = \
    #         cls.gen_func_along_axes(DataFrame.mean, 0, 1)
    #     table_cls.period_max, table_cls.max = \
    #         cls.gen_func_along_axes(DataFrame.max, 0, 1)
    #     table_cls.period_min, table_cls.min = \
    #         cls.gen_func_along_axes(DataFrame.min, 0, 1)
    #     table_cls.period_count_nz, table_cls.count_nz = \
    #         cls.gen_func_along_axes(lambda d, axis=0: d.fillna(0).astype(bool).sum(axis=axis), 0, 1)
    #     table_cls.period_concat, table_cls.concat = \
    #         cls.gen_func_along_axes(lambda *args, axis=1: pd.concat(args, axis=axis), 0, 1)

    @tf_over_values
    def tf_easy_interpolate(self, data, **kwargs):
        kwargs["limit_direction"] = kwargs.get("limit_direction", "both")
        return easy_interpolate(data, **kwargs)
