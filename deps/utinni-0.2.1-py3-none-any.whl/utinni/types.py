from numbers import Number
from typing import TypeAlias, Union

import pandas as pd


Dim0ValueType: TypeAlias = Number
Dim1ValueType: TypeAlias = pd.Series
Dim2ValueType: TypeAlias = pd.DataFrame
Dim3ValueType: TypeAlias = dict[str, pd.DataFrame]
ValueType: TypeAlias = Union[Dim0ValueType, Dim1ValueType, Dim2ValueType, Dim3ValueType]

DFSType: TypeAlias = Union[pd.DataFrame, pd.Series]
