from pathlib import Path

import typer
import uvicorn
from dynaconf import Dynaconf
from fastapi import FastAPI

from .router import router
from ..utils import import_cookbook


def main(cookbook: list[str],
         config: list[Path] = typer.Option(None, "--conf", "-c"),
         host: str = typer.Option("127.0.0.1", "--host", "-h")):
    conf = Dynaconf(settings_files=config or ["./config.toml"])
    router.setup(conf)
    cookbooks = {}
    for loc in cookbook:
        name, cb = import_cookbook(loc)
        cookbooks[name] = cookbooks.get(name, [])
        cookbooks[name].append(cb)
    router.add_cookbooks(cookbooks)
    fastapi_app = FastAPI()
    fastapi_app.include_router(router)
    uvicorn.run(fastapi_app, host=host)


def run():
    typer.run(main)
