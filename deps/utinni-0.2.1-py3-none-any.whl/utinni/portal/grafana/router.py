from datetime import timedelta, datetime
from typing import Union

import numpy as np
import pandas as pd
from dateutil import parser
from fastapi import Body, APIRouter
from pydantic import BaseModel
from pytz import UTC

from ...context import Context
from ...pump import WrappedDataPump
from ...types import Dim0ValueType, Dim1ValueType, Dim2ValueType
from ...utils import chainable


def _format_datapoints(series: pd.Series, name=None, timestamps=None, **kwargs):
    return dict(
        target=name or series.name,
        datapoints=list(zip(
            series.to_list(),
            timestamps or [datetime.timestamp(x) * 1e3 for x in series.index]
        ))
    ) | kwargs


def _guess_column_type(column):
    kind = column.dtype.kind
    if kind in "b":
        return "boolean"
    elif kind in "iufc":
        return "number"
    elif kind in "OSU":
        return "string"
    elif kind in "M":
        return "time"
    else:
        return "unknown"


def _clean_dataframe(df):
    return df.replace({np.nan: None}).replace({np.inf: None})


def _format_dataframe_fields(table, index_name=None, name=None, **kwargs):
    # TODO: grafana_datasource cannot detect data range if time-series data are also returned by this format
    fields = []
    value = _clean_dataframe(table.value)
    if isinstance(value, pd.Series):
        fields.append(dict(
            name=name or value.name,
            type=_guess_column_type(value),
            values=value.to_list()
        ))
    else:
        fields.append(dict(
            name=str(value.index.name or index_name or "index"),
            type=_guess_column_type(value.index),
            values=value.index.to_list()
        ))
        for column in value:
            series = value[column]
            fields.append(dict(
                name=str(series.name),
                type=_guess_column_type(series),
                values=series.to_list()
            ))
    return dict(fields=fields) | kwargs


def _is_time_series(value):
    if isinstance(value, Dim0ValueType):
        return False
    elif isinstance(value, Dim1ValueType):
        return isinstance(value.index, pd.DatetimeIndex)
    elif isinstance(value, Dim2ValueType):
        return isinstance(value.index, pd.DatetimeIndex)
    elif isinstance(value, dict):
        return all(isinstance(v.index, pd.DatetimeIndex) for v in value.values())


def _append_table_to_result(results, table, name=None, **kwargs):
    name = name or table.name
    value = table.value
    if isinstance(value, dict):
        for k, v in value.items():
            _append_table_to_result(results, table[v], name=k, **kwargs)
    elif isinstance(value, Dim0ValueType):
        _append_table_to_result(results, table.ascent(), name=name)
    else:
        if _is_time_series(value):
            value = _clean_dataframe(value)
            timestamps = [datetime.timestamp(x) * 1e3 for x in value.index]
            if isinstance(value, pd.Series):
                results.append(_format_datapoints(value, name=name, timestamps=timestamps, **kwargs))
            else:
                for column in value:
                    results.append(_format_datapoints(value[column], name=column, timestamps=timestamps, **kwargs))
        else:
            results.append(_format_dataframe_fields(table, name=name, **kwargs))
    return results


class SpecialTargetsHandler:
    def __init__(self):
        self.targets = {}

    @classmethod
    def on_target_definition_nodes(cls, context, results):
        graph = context.graph(name_only=True, ignore_none=True)
        edge_df = pd.DataFrame(graph.edges, columns=["source", "target"])
        edge_df.index.name = "id"
        edge_df.index = edge_df.index.astype(str)
        edge_table = context.portal_wrap_table(edge_df)
        node_df = pd.DataFrame(graph.nodes, columns=["id"]).set_index("id")
        node_df["mainStat"] = node_df.index
        node_table = context.portal_wrap_table(node_df)
        _append_table_to_result(results, edge_table, name="edges")
        _append_table_to_result(results, node_table, name="nodes")

    @classmethod
    def all_special_targets(cls):
        for item in dir(cls):
            if item.startswith("on_target_"):
                yield item.removeprefix("on_target")

    def filter_special_target(self, target):
        handler = getattr(self, f"on_target{target}", None)
        if handler:
            self.targets[target] = handler
            return True
        else:
            return False

    def process_and_append(self, dl, results):
        for target, handler in self.targets.items():
            handler(dl, results)


class GrafanaDatasourceAPI(APIRouter):
    def __init__(self, *args, **kwargs):
        super(GrafanaDatasourceAPI, self).__init__(*args, **kwargs)
        self.client = None
        self.cookbooks = {}
        self.config = None

    @chainable
    def setup(self, config, cookbooks=None):
        self.cookbooks = cookbooks or {}
        self.config = config

    @chainable
    def add_cookbooks(self, cookbooks):
        self.cookbooks |= cookbooks

    def prepare_context(self, context_name):
        context = Context()
        context.add_pump("portal_wrap", WrappedDataPump())
        for cookbook in self.cookbooks[context_name]:
            cookbook(context, self.config)
        return context.bind(**self.config.on_request)


router = GrafanaDatasourceAPI()


@router.get("/{context}/", status_code=200)
async def test(context: str):
    pass


class SearchBody(BaseModel):
    target: str = "metrics"
    measurement: Union[str, None] = None


@router.post("/{context}/search")
async def search(context: str, body=Body(...)):
    context: Context = router.prepare_context(context)
    return list(context.defs.keys()) + ["Custom"] + list(SpecialTargetsHandler.all_special_targets())


@router.post("/{context}/query")
async def query(context: str, body=Body(...)):
    start = parser.isoparse(body["range"]["from"]).replace(tzinfo=UTC)
    stop = parser.isoparse(body["range"]["to"]).replace(tzinfo=UTC)
    step = timedelta(seconds=body["intervalMs"] / 1000)
    context: Context = router.prepare_context(context)
    targets = body["targets"]
    defs = {}
    special_target_handler = SpecialTargetsHandler()
    for target in targets:
        target_name = target["target"]
        if special_target_handler.filter_special_target(target_name):
            continue
        if target_name == "Custom" and target["payload"]:
            _target = context.parse(target["payload"])
        else:
            _target = context.get_define(target_name)
        if not target["refId"].startswith("_"):
            target_name = target["refId"]
        defs[target_name] = _target
    context.bind(start=start, stop=stop, step=step).optimise(defs.values())
    res = []
    for target_name, target in defs.items():
        if target is not None:
            res = _append_table_to_result(res, target, name=target_name)
    special_target_handler.process_and_append(context, results=res)
    return res
