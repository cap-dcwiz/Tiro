from copy import copy


class ConfigDict(dict):
    def __getattr__(self, item):
        return self.get(item)


class Configurable:
    """The subclass of this will receive required configs when Context.bind is called"""

    def __init__(self, *args, **kwargs):
        self.config = ConfigDict({k: v for k, v, _ in self.config_items()})

    def new_or_current_config(self, config, name, default=None):
        item = config.get(name, None)
        if item is None:
            return self.config.get(name, default)
        else:
            return item

    def config_items(self):
        return
        yield

    def extract_config(self, config: dict[str, ...]) -> dict[str, ...]:
        return copy(config)

    def update_config(self, **kwargs):
        self.config |= self.extract_config(kwargs)
