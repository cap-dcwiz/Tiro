from traceback import format_exc

from builtins import list
from datetime import datetime, timedelta
from typing import Optional, Union

from fastapi import HTTPException
from pydantic import BaseModel

from utinni import Context
from utinni.portal.base import PortalAPIRouterBase


class QueryBodyModel(BaseModel):
    names: list[str]
    influxdb_bucket: Optional[str] = None
    influxdb_measurement: Optional[str] = None
    start: Optional[datetime] = None
    stop: Optional[datetime] = None
    step: Optional[Union[int, str]] = None
    interpolate: Optional[bool] = None
    interpolate_limit: Optional[Union[int, str]] = None
    interpolate_fill_na: Optional[Union[int, float, str]] = None
    merge_results: bool = False
    drop_na: bool = False

    class Config:
        schema_extra = {
            "example": {
                "names": ["cp_pue", "cp_cop"],
                "start": datetime.utcnow() - timedelta(hours=1),
                "stop": datetime.utcnow(),
                "step": 300,
                "merge_results": True,
                "drop_na": False,
                "interpolate": True,
                "interpolate_limit": "3600s",
                "interpolate_fill_na": False
            }
        }

    def format_query_options(self):
        options = dict(
            start=self.start or datetime.utcnow() - timedelta(hours=1),
            stop=self.stop or datetime.utcnow(),
            step=self.step,
        )
        if self.influxdb_bucket is not None:
            options["influxdb_bucket"] = self.influxdb_bucket
        if self.influxdb_measurement is not None:
            options["influxdb_measurement"] = self.influxdb_measurement
        if self.interpolate is not None:
            options["interpolate"] = self.interpolate
        if self.interpolate_limit is not None:
            options["interpolate_limit"] = self.interpolate_limit
        if self.interpolate_fill_na is not None:
            if isinstance(self.interpolate_fill_na, str) and self.interpolate_fill_na.lower() in ("false", "no_fill"):
                options["interpolate_fill_na"] = False
            else:
                options["interpolate_fill_na"] = self.interpolate_fill_na
        return options


router = PortalAPIRouterBase()


@router.get("/")
async def list_context():
    return list(router.cookbooks.keys())


@router.get("/{context}/")
async def list_definitions(context: str):
    ctx: Context = router.prepare_context(context)
    return ctx.list_define()


@router.post("/{context}/query")
async def query(context: str, body: QueryBodyModel):
    ctx: Context = router.prepare_context(context)
    ctx.bind(**body.format_query_options())
    try:
        if body.merge_results:
            defs = [ctx.get_define(i) for i in body.names]
            item = defs[0].aggregate(*defs[1:])
            if body.drop_na:
                item = item.dropna()
            return item.to_native_type(replace_nan=True).value
        else:
            res = {}
            ctx.optimise(body.names)
            for name in body.names:
                item = ctx.get_define(name)
                if item is None:
                    raise HTTPException(status_code=500, detail=f"Cannot find definition {name}")
                if body.drop_na:
                    item = item.dropna()
                res[name] = item.to_native_type(replace_nan=True).value
            return res
    except Exception:
        raise HTTPException(status_code=500, detail=format_exc())
