from abc import ABC, abstractmethod
from numbers import Number
from typing import Optional

import pandas as pd

from utinni.types import ValueType


class TableABC(ABC):
    @property
    @abstractmethod
    def value(self):
        pass


class SingletonBase:
    _instance = {}

    def __new__(cls, context, *args, **kwargs):
        context_instances = cls._instance.get(context, {})
        cls._instance[context] = context_instances
        context_instances[cls] = context_instances.get(cls, super(SingletonBase, cls).__new__(cls, *args, **kwargs))
        return context_instances[cls]