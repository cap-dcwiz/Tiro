from .base import DataPump
from ..table.table import PrimaryTable
from ..types import ValueType


class WrappedDataPump(DataPump):
    def gen_table(self, origin):
        return PrimaryTable(context=self.context,
                            pump=self,
                            meta=dict(origin=origin))

    def get_data(self, table, fields) -> ValueType:
        if fields is None:
            return table.meta["origin"]
        else:
            return table.meta["origin"][fields]
