from . import echo

PLUGINS = dict(
    echo=echo.Aggregator,
)
