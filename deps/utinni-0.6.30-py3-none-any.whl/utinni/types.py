from numbers import Number
from typing import TypeAlias, Union, Any

import pandas as pd


Dim0ValueType: TypeAlias = Number
Dim1ValueType: TypeAlias = pd.Series
Dim2ValueType: TypeAlias = pd.DataFrame
Dim3ValueType: TypeAlias = dict[str, pd.DataFrame]
DimFreeValueType: TypeAlias = Any
ValueType: TypeAlias = Union[Dim0ValueType, Dim1ValueType, Dim2ValueType, Dim3ValueType, DimFreeValueType]

DFSType: TypeAlias = Union[pd.DataFrame, pd.Series]


def guess_value_dimension(data: ValueType) -> int:
    if isinstance(data, dict) and all(isinstance(v, pd.DataFrame) for v in data.values()):
        return 3
    elif isinstance(data, pd.DataFrame):
        return 2
    elif isinstance(data, pd.Series):
        return 1
    elif isinstance(data, Number):
        return 0
    else:
        return -1
