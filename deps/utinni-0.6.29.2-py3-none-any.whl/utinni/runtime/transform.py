import logging
from functools import partial
from typing import Callable, Union

import numpy as np
import pandas as pd
from itertools import chain
from pandas import Series

from ..abc import TableABC
from ..types import ValueType, guess_value_dimension
from ..utils import easy_interpolate


class Transform:
    def __init__(self, method, dependency_method=None):
        self.method = method
        self.dependency_method = dependency_method or self.default_dependency_method

    def record_dependency(self, method):
        self.dependency_method = method
        return method

    def default_dependency_method(self, *args, **kwargs):
        for arg in chain(args, kwargs.values()):
            if isinstance(arg, TableABC):
                yield arg, "ALL", "ALL"

    def partial(self, *args, **kwargs):
        method = partial(self.method, *args, **kwargs)
        dep_method = partial(self.dependency_method, *args, **kwargs)
        return self.__class__(method, dep_method)

    def calculate_field_dependencies(self, *args, **kwargs):
        return self.dependency_method(*args, **kwargs)


class TransformOverValues(Transform):
    def __call__(self, *args, **kwargs):
        args = [arg.value if isinstance(arg, TableABC) else arg for arg in args]
        kwargs = {k: v.value if isinstance(v, TableABC) else v for k, v in kwargs.items()}
        if any(arg is NotImplemented for arg in chain(args, kwargs.values())):
            logging.info("Some values are not implemented, skipping calculation")
            return NotImplemented
        return self.method(*args, **kwargs)


class TransformOverTables(Transform):
    def __call__(self, *args, **kwargs):
        return self.method(*args, **kwargs)


tf_over_values = TransformOverValues
tf_over_tables = TransformOverTables


class TransformLibrary:
    def __getitem__(self, item):
        func = getattr(self, f"tf_{item}", None)
        if func:
            return func.partial(self)

    @staticmethod
    def gen_bin_op(s):
        def _get_real_op(value, pos):
            dimension = guess_value_dimension(value)
            if pos == 0:
                _op = s
            else:
                _op = "r" + s
            if 0 <= dimension <= 2:
                return getattr(value, f"__{_op}__")
            elif dimension == 3:
                # TODO: Untested
                return lambda other: {k: getattr(v, _op)(other) for k, v in value.items()}
            else:
                return partial(getattr(value, _op))

        def _tf(value, other):
            return _get_real_op(value, 0)(other)

        def _rtf(value, other):
            return _get_real_op(value, 1)(other)

        def op(self, other):
            return self.apply_tf(_tf, other)

        def rop(self, other):
            return self.apply_tf(_rtf, other)

        return op, rop

    @staticmethod
    def gen_func(func: Callable[..., ValueType]):
        def _get_real_func(value):
            dimension = guess_value_dimension(value)
            if dimension == 3:
                # TODO: Untested
                return lambda _, *args, **kwargs: {k: func(v, *args, **kwargs) for k, v in value.items()}
            else:
                return func

        def _tf(value, *args, **kwargs):
            return _get_real_func(value)(value, *args, **kwargs)

        def op(self, *args, **kwargs):
            return self.apply_tf(_tf, *args, **kwargs)

        return op

    @classmethod
    def gen_func_along_axes(cls, func: Callable[..., ValueType], *axes):
        return [cls.gen_func(partial(func, axis=axis)) for axis in axes]

    @classmethod
    def install_special_and_predefined_methods(cls, table_cls):
        table_cls.__add__, table_cls.__radd__ = cls.gen_bin_op("add")
        table_cls.__mul__, table_cls.__rmul__ = cls.gen_bin_op("mul")
        table_cls.__sub__, table_cls.__rsub__ = cls.gen_bin_op("sub")
        table_cls.__truediv__, table_cls.__rtruediv__ = cls.gen_bin_op("truediv")
        table_cls.__floordiv__, table_cls.__rfloordiv__ = cls.gen_bin_op("floordiv")
        table_cls.__le__, _ = cls.gen_bin_op("le")
        table_cls.__lt__, _ = cls.gen_bin_op("lt")
        table_cls.__gt__, _ = cls.gen_bin_op("gt")
        table_cls.__ge__, _ = cls.gen_bin_op("ge")
        table_cls.__eq__, _ = cls.gen_bin_op("eq")
        table_cls.__ne__, _ = cls.gen_bin_op("ne")
        table_cls.__pow__ = cls.gen_func(pow)
        table_cls.__abs__ = cls.gen_func(abs)
        table_cls.__neg__ = cls.gen_func(lambda x: -x)

    @tf_over_tables
    def tf_ascent(self, table: "TableBase", name: str = None) -> ValueType:
        value = table.value
        dimension = table.dimension
        if dimension == 0:
            result = Series({(name or table.name): value})
        elif dimension == 1:
            result = value.to_frame(name=name or table.name or value.name)
        elif dimension == 2:
            result = {(name or table.name): value}
        else:
            raise ValueError("Only 0/1/2-D value can be ascended.")
        return result

    @tf_ascent.record_dependency
    def _(self, table, name=None):
        yield table, "ALL", name or table.name or "ALL"

    @tf_over_tables
    def tf_aggregate(self, *tables: "TableBase") -> ValueType:
        dimension = tables[0].dimension
        if dimension == 0:
            if all(t.name is not None for t in tables):
                result = Series({t.name: t.value for t in tables})
            else:
                result = Series([t.value for t in tables])
        elif dimension == 1:
            result = pd.concat([t.value for t in tables], axis=1)
        elif dimension == 2:
            result = {t.name: t.value for t in tables}
        elif dimension is None:
            if all(getattr(t.value, "name") for t in tables):
                result = {t.value.name: t.value for t in tables}
            else:
                result = [t.value for t in tables]
        else:
            raise ValueError("Only 0/1/2-D value can be aggregated.")
        return result

    @tf_aggregate.record_dependency
    def _(self, *tables):
        for table in tables:
            if table.name:
                yield table, "ALL", table.name
            else:
                yield table, "ALL", "ALL"

    @tf_over_values
    def tf_concat(self, *values: ValueType) -> ValueType:
        dimension = guess_value_dimension(values[0])
        if dimension == 1:
            result = pd.concat(values, axis=0)
        elif dimension == 2:
            result = pd.concat(values, axis=1)
        elif dimension == 3:
            result = {}
            for v in values:
                result |= v
        elif dimension < 0:
            result = values
        else:
            raise ValueError("Can only concat 1/2/3/free-D values")
        return result

    @tf_concat.record_dependency
    def _(self, *tables):
        for table in tables:
            yield table, "ALL", "ALL"

    @tf_over_values
    def tf_extract(self, value: ValueType, name: Union[str, list[str]]) -> ValueType:
        dimension = guess_value_dimension(value)
        if dimension == 1:
            if isinstance(name, list):
                result = value[value.index.isin(name)]
            else:
                result = value[name]
        elif dimension == 2:
            result = value[name]
        elif dimension == 3:
            if isinstance(name, list):
                result = {k: v for k, v in value.items() if k in name}
            else:
                result = value[name]
        elif dimension < 0 and hasattr(value, "__getitem__"):
            result = value[name]
        else:
            raise ValueError("Can only extract from 1/2/3-D value or value with __getitem__ method")
        return result

    @tf_extract.record_dependency
    def _(self, table, name):
        if isinstance(name, str):
            yield table, name, "ALL"
        else:
            for item in name:
                yield table, item, item

    @tf_over_values
    def tf_remove_zeros(self, data):
        return data.replace(0, np.NAN)

    @tf_over_values
    def tf_dropna(self, data, include_inf=False, **kwargs):
        if include_inf:
            data = data.replace([np.inf, -np.inf], np.nan)
        return data.dropna(**kwargs)

    @tf_over_values
    def tf_count_nz(self, data, **kwargs):
        return data.fillna(0).astype(bool).sum(**kwargs)

    @tf_over_values
    def tf_period_total(self, data):
        total_second = (data.index.max() - data.index.min()).total_seconds()
        return data.mean(axis=0) * total_second

    @tf_over_values
    def tf_filter_columns(self, data, func):
        dimension = guess_value_dimension(data)
        if dimension == 2:
            return data[[c for c in data.columns if func(c)]]
        elif dimension == 3:
            return {k: v[[c for c in v.columns if func(c)]] for k, v in data.items()}
        else:
            raise ValueError(f"Unexpected value type: {type(data)}")

    @tf_over_values
    def tf_filter_rows(self, data, func):
        dimension = guess_value_dimension(data)
        if dimension == 1 or dimension == 2:
            return data[func(data)]
        elif dimension == 3:
            return {k: v[func(v)] for k, v in data.items()}
        else:
            raise ValueError(f"Unexpected value type: {type(data)}")

    @tf_over_values
    def tf_iloc(self, data, index):
        dimension = guess_value_dimension(data)
        if dimension == 1 or dimension == 2:
            return data.iloc[index]
        else:
            raise ValueError(f"iloc not support on value type: {type(data)}")

    @tf_over_values
    def tf_to_native_type(self, data, replace_nan=False, **kwargs):
        dimension = guess_value_dimension(data)
        if dimension <= 0:
            return data
        elif 1 <= dimension <= 2:
            if replace_nan:
                data = data.replace({np.nan: None})
            return data.to_dict(**kwargs)
        elif dimension == 3:
            res = {}
            for k, v in data.items():
                if replace_nan:
                    v = v.replace({np.nan: None})
                res[k] = v.to_dict(**kwargs)
            return res
        else:
            raise ValueError(f"Wrong dimension: {dimension}")


class TransformLibraryForTSTable(TransformLibrary):
    @tf_over_values
    def tf_easy_interpolate(self, data, **kwargs):
        kwargs["limit_direction"] = kwargs.get("limit_direction", "both")
        return easy_interpolate(data, **kwargs)
