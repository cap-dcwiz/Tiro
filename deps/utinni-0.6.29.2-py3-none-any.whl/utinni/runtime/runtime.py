from typing import Callable, Union
from uuid import uuid1

from networkx import DiGraph
from pygraphviz import AGraph

from .transform import tf_over_values, Transform
from .dependency import DependencyManager
from .dsl import define_expr
from ..table.base import TableBase
from ..table.table import SecondaryTable, PrimaryTable
from ..types import ValueType
from ..utils import chainable


class Runtime:
    def __init__(self, context):
        self.context = context
        self.dmngr = DependencyManager()
        self.defs: dict[str, TableBase] = {}

        # If a table's dirty_flag does not match the runtime's, the table need to be re-calculated
        self._dirty_flag = uuid1()

    @property
    def dirty_flag(self):
        return self._dirty_flag

    @chainable
    def mark_dirty(self):
        self._dirty_flag = uuid1()

    @chainable
    def define(self, key, value):
        if isinstance(value, str):
            value = self.parse(value)
        self.defs[key] = value.set_name(key)

    def list_define(self) -> list[str]:
        return list(self.defs.keys())

    def get_define(self, key) -> TableBase:
        return self.defs.get(key)

    def has_define(self, key) -> bool:
        return key in self.defs

    @chainable
    def remove_dev(self, key):
        del self.defs[key]

    @chainable
    def clear_def(self):
        self.defs.clear()

    def __iter__(self):
        for v in self.defs.values():
            yield v

    def filter_defs(self, func=None):
        """
        Filter out measurement by the given function (optional)
        """
        return filter(func, self.defs.values())

    def make_secondary_table(self, transform: Union[Callable[..., ValueType], Transform], *args, **kwargs):
        if not isinstance(transform, Transform):
            transform = tf_over_values(transform)
        return SecondaryTable(context=self.context,
                              tf_method=transform,
                              tf_args=args,
                              tf_kwargs=kwargs)

    def revise_dependency_graph(self, table: TableBase):
        return self.dmngr.revise_dependency_graph(table)

    def parse(self, expression: str) -> TableBase:
        expr = define_expr(self.defs.keys())
        return expr.parse_string(expression)[0].eval(self)

    def graph(self, tables=None, name_only=False, ignore_none=True) -> DiGraph:
        """Return the dependency graph of all tables in self.defs"""
        return self.dmngr.dependency_graph(tables or self.defs.values(), name_only, ignore_none)

    def agraph(self, *args, **kwargs) -> AGraph:
        import networkx as nx

        g = self.graph(*args, **kwargs)
        return nx.nx_agraph.to_agraph(g)

    def draw_deps(self, filename, prog="dot", **kwargs):
        return self.agraph(**kwargs).draw(filename, prog=prog)

    def plot_deps(self, tables=None, prog="dot", **kwargs):
        from IPython.display import SVG

        return SVG(self.agraph(tables, **kwargs).draw(format="svg", prog=prog))

    @chainable
    def mark_fields_for_table(self, table):
        for primary_table, fields in table.primary_ancestors_and_fields():
            primary_table.mark_fields(*fields)

    @chainable
    def optimise(self,
                 tables: Union[list[Union[TableBase, str]],
                               dict[..., Union[TableBase, str]]]
                 ):
        affected_primary_tables = []
        if isinstance(tables, dict):
            tables = tables.values()
        for table in tables:
            if isinstance(table, str):
                table = self.get_define(table)
                if not table:
                    continue
            for primary_table, fields in table.primary_ancestors_and_fields():
                affected_primary_tables.append([primary_table, fields])
                primary_table.reset_fields()
        for primary_table, fields in affected_primary_tables:
            primary_table.mark_fields(*fields)

    def reset_fields(self):
        for table in self.defs.values():
            if isinstance(table, PrimaryTable):
                table.reset_fields()

    @chainable
    def collect(self, dic, clear_existing=False):
        if clear_existing:
            self.clear_def()
        for k, v in list(dic.items()):
            if isinstance(v, TableBase) and not k.startswith("_"):
                self.define(k, v)

    @staticmethod
    def aggregate(*tables):
        return tables[0].aggregate(*tables[1:])

    @staticmethod
    def concat(*tables):
        return tables[0].concat(*tables[1:])
