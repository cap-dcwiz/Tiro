from copy import copy


class ConfigDict(dict):
    def __getattr__(self, item):
        return self.get(item)


class OverwrittenConfig:
    def __init__(self, overwrite_dict, *existing_dicts):
        self.overwrite_dict = overwrite_dict
        self.existing_dicts = existing_dicts

    def __getattr__(self, item):
        if item in self.overwrite_dict:
            return self.overwrite_dict[item]
        for d in self.existing_dicts:
            if item in d:
                return d[item]
        return None


class Configurable:
    """The subclass of this will receive required configs when Context.bind is called"""

    def __init__(self, *args, **kwargs):
        self.config = ConfigDict({k: v for k, v, _ in self.config_items()})

    def new_or_current_config(self, config, name, default=None):
        item = config.get(name, NotImplemented)
        if item is NotImplemented:
            return self.config.get(name, default)
        else:
            return item

    def config_items(self):
        return
        yield

    def extract_config(self, config: dict[str, ...]) -> dict[str, ...]:
        return copy(config)

    def update_config(self, **kwargs):
        self.config |= self.extract_config(kwargs)
