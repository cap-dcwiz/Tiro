import logging
from copy import copy
from datetime import timedelta, datetime
from numbers import Number
from typing import Union, TypeAlias, Optional

from influxdb_client import InfluxDBClient
from pandas import DataFrame

from .base import TimeSeriesDataPump
from ..table.table import TimeSeriesPrimaryTable
from ..types import Dim3ValueType, Dim2ValueType, ValueType

QUERY_FLUX_HEAD = """
from(bucket: _bucket)
  |> range(start: _start, stop: _stop)
  |> filter(fn: (r) => r["_measurement"] == _measurement)"""

QUERY_FLUX_AGG_WIN = """
  |> aggregateWindow(every: {time_step}, fn: {agg_fn}, createEmpty: false, timeSrc: "_start")"""

QUERY_FLUX_TAIL = """
  |> keep(columns: _columns)
  |> pivot(columnKey: _column_key, rowKey: ["_time"], valueColumn: "_value")"""

STEP_REPLACE_MAP = {
    "MS": "mo",
    "M": "mo",
}


class NoValidDataFoundException(RuntimeError):
    pass


def _append_filter(flux_str, field, candidates):
    if candidates is not None:
        if candidates:
            _filter = " or ".join(f'r["{field}"] == "{c}"' for c in candidates)
        else:
            _filter = "false"
        return flux_str + f"\n  |> filter(fn: (r) => {_filter})"
    else:
        return flux_str


FilterValueType = Union[str, Number]
FilterKeyType = str
FilterType: TypeAlias = dict[FilterKeyType, Union[FilterValueType, list[FilterValueType]]]


class InfluxDBDataPump(TimeSeriesDataPump):
    def __init__(self, *args,
                 influxdb_url="http://localhost:8086",
                 influxdb_token=None,
                 influxdb_org=None,
                 influxdb_client=None,
                 **kwargs):
        super(InfluxDBDataPump, self).__init__(*args, **kwargs)
        if influxdb_client is None and influxdb_token is not None:
            self._client_params = dict(url=influxdb_url,
                                       token=influxdb_token,
                                       org=influxdb_org,
                                       verify_ssl=False)
        else:
            self._client_params = None
        self._client: InfluxDBClient = influxdb_client
        self.query_cache = {}

    @property
    def client(self):
        if self._client is None:
            if self._client_params:
                client = InfluxDBClient(**self._client_params, timeout=60_000)
            else:
                client = self.context.clients.get("influxdb", None)
            self._client = client
        return self._client

    def config_items(self):
        yield from super(InfluxDBDataPump, self).config_items()
        yield "influxdb_bucket", None, None
        yield "influxdb_measurement", None, None

    def extract_config(self, config: dict[str, ...]) -> dict[str, ...]:
        _config = super(InfluxDBDataPump, self).extract_config(config)
        return _config | dict(influxdb_bucket=self.new_or_current_config(config, "influxdb_bucket"),
                              influxdb_measurement=self.new_or_current_config(config, "influxdb_measurement"))

    def gen_table(self,
                  field=None,
                  column="_field",
                  agg_fn="mean",
                  include_tags=None,
                  table_cls=TimeSeriesPrimaryTable,
                  **filters):
        return table_cls(context=self.context,
                         pump=self,
                         fields=field,
                         meta=dict(column=column,
                                   filters=filters,
                                   agg_fn=agg_fn,
                                   include_tags=include_tags))

    def __getitem__(self, item):
        table = self.query_cache.get(item, self.default_query(item))
        self.query_cache[table] = table
        return table

    def default_query(self, item):
        return None

    def get_data(self, table: TimeSeriesPrimaryTable, fields) -> ValueType:
        config = table.config
        return self.query(bucket=config.influxdb_bucket,
                          measurement=config.influxdb_measurement,
                          start=config.start,
                          stop=config.stop,
                          step=config.step,
                          field=fields,
                          filters=table.meta["filters"],
                          column=table.meta["column"],
                          agg_fn=table.meta["agg_fn"],
                          include_tags=set(table.meta["include_tags"] or {}))

    def post_process_query(self, data):
        to_be_dropped = ("table", "result", "_field", "_start", "_stop", "_measurement")
        if isinstance(data, DataFrame):
            columns = [x for x in to_be_dropped if x in data]
            return data.drop(columns=columns).set_index("_time")
        else:
            return {k: self.post_process_query(v) for k, v in data.items()}

    def query(self,
              bucket: str,
              measurement: str,
              start: datetime,
              stop: datetime,
              step: Union[timedelta, str, int, float],
              field: Union[str, list[str]] = None,
              filters: FilterType = None,
              column: str = "_field",
              include_tags: set[str] = None,
              agg_fn: str = "mean",
              ) -> Union[Dim2ValueType, Dim3ValueType]:
        """
        Query data from influxdb
        :param start:
        :param stop:
        :param step:
        :param config: configurations
        :param field: the field that will be the value of generated table.
                      Can be a list, in which case a dict of fields and DataFrames will be returned.
        :param filters: dict of tag_name and choices
        :param column: Tag name that will be used as table columns
        :param include_tags:
        :param agg_fn:
        :return:
        """
        flux_str = copy(QUERY_FLUX_HEAD)

        if field:
            if isinstance(field, list):
                flux_str = _append_filter(flux_str, "_field", list(field))
            elif isinstance(field, str):
                flux_str = _append_filter(flux_str, "_field", [field])
            else:
                raise TypeError("field must be str or list[str]")

        if filters:
            for key, values in filters.items():
                if isinstance(values, list):
                    values = list(values)
                else:
                    values = [values]
                flux_str = _append_filter(flux_str, key, values)

        if step is not None:
            flux_str += QUERY_FLUX_AGG_WIN
            if isinstance(step, str):
                for k, v in STEP_REPLACE_MAP.items():
                    if k in step:
                        step = step.replace(k, v)
            elif isinstance(step, timedelta):
                step = f"{int(step.total_seconds())}s"
            else:
                step = f"{int(step)}s"

        if column:
            columns = {"_time", "_field", "_value"} | {column} | set(include_tags or {})
            column_key = column
            flux_str += QUERY_FLUX_TAIL
        else:
            columns = ""
            column_key = ""

        flux_str = flux_str.format(agg_fn=agg_fn, time_step=step)
        logging.debug(f"INFLUXDB QUERY: {flux_str} \n"
                      f"start={start} \n"
                      f"stop={stop} \n"
                      f"step={step} \n"
                      f"bucket={bucket} \n"
                      f"measurement={measurement} \n"
                      f"_columns={columns} \n"
                      f"_column_key={column_key}")
        response = self.client.query_api().query_data_frame(
            flux_str,
            params={
                "_bucket": bucket,
                "_start": start,
                "_stop": stop,
                "_measurement": measurement,
                "_columns": columns,
                "_column_key": [column_key]
            })
        if isinstance(response, list):
            ret = {}
            for r in response:
                if "_field" in r:
                    if r.table.nunique() > 1:
                        ret |= {k: g for k, g in r.groupby("_field")}
                    else:
                        ret |= {r.iloc[0]["_field"]: r}
                else:
                    ret |= {field: r}
        else:
            if response.empty:
                raise NoValidDataFoundException("Cannot find any data in TSDB.")
            if "_field" in response:
                if response.table.nunique() > 1:
                    ret = {k: g for k, g in response.groupby("_field")}
                elif not field or isinstance(field, list):
                    ret = {response.iloc[0]["_field"]: response}
                else:
                    ret = response
            elif isinstance(field, str):
                ret = {field: response}
            else:
                ret = response
        return self.post_process_query(ret)
