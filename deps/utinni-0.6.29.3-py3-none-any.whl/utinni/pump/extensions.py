from .tsdb import InfluxDBDataPump


class DCWizTelemetryPump(InfluxDBDataPump):
    def default_query(self, item):
        return self.gen_table(dev_type=item, column="dev_name")
