import operator as op

from pyparsing import oneOf, opAssoc, Word, Forward, ZeroOrMore,\
    Suppress, OpAssoc, alphanums, infixNotation, \
    pyparsing_common as pp_common


class Node:
    def __init__(self, tokens):
        self.tokens = tokens

    def __repr__(self):
        return f"{self.__class__.__name__}:{self.tokens}"

    def eval(self, runtime):
        return self


class OpNode(Node):
    Operator = (NotImplemented,) * 5

    def __init__(self, tokens):
        super(OpNode, self).__init__(tokens)
        self.func_map = {k: v for k, v in zip(self.Operator[0].split(), self.Operator[3])}

    def eval(self, runtime):
        num_ops = self.Operator[1]
        if num_ops == 1:
            op_func = self.func_map[self.tokens[0][self.Operator[4]]]
            args = [t.eval(runtime) for t in self.tokens[0] if isinstance(t, Node)]
            return op_func(*args[:num_ops])
        elif num_ops == 2:
            res = None
            op_func = None
            for item in self.tokens[0]:
                if isinstance(item, Node):
                    if res is None:
                        res = item.eval(runtime)
                    else:
                        if op_func is None:
                            raise RuntimeError("Missing operator")
                        else:
                            res = op_func(res, item.eval(runtime))
                else:
                    op_func = self.func_map.get(item, None)
                    if op_func is None:
                        raise RuntimeError(f"Unknown operator: {item}")
            return res
        else:
            raise NotImplementedError

    @classmethod
    def to_infix_op_list(cls):
        return oneOf(cls.Operator[0]), *cls.Operator[1:3], cls


class TableNode(Node):
    def eval(self, runtime):
        return runtime.get_define(self.tokens[0])


class NumberNode(Node):
    def eval(self, runtime):
        return self.tokens[0]


class FuncCallNode(Node):
    def eval(self, runtime):
        func_name = self.tokens[0]
        args = [t.eval(runtime) for t in self.tokens[1:]]
        return getattr(args[0], func_name)(*args[1:])


class PowOp(OpNode):
    Operator = "^", 2, opAssoc.RIGHT, (op.pow,), 1


class SignOp(OpNode):
    Operator = "+ -", 1, opAssoc.RIGHT, (op.pos, op.neg), 0


class MulOp(OpNode):
    Operator = "* / // %", 2, OpAssoc.LEFT, (op.mul, op.truediv, op.floordiv, op.mod), 1


class PlusOp(OpNode):
    Operator = "+ -", 2, OpAssoc.LEFT, (op.add, op.sub), 1


def define_expr(pre_defs):
    func_name = Word(alphanums + "_")
    expr = Forward()
    func_args = expr + ZeroOrMore(Suppress(",") + expr)
    func_call = func_name + Suppress("(") + func_args + Suppress(")")
    table = oneOf(" ".join(pre_defs))
    number = pp_common.number
    expr <<= infixNotation(
        table | number | func_call,
        [x.to_infix_op_list() for x in [PowOp, SignOp, MulOp, PlusOp]],
    )
    func_call.set_parse_action(FuncCallNode)
    table.set_parse_action(TableNode)
    number.set_parse_action(NumberNode)
    return expr
