from copy import copy
from typing import Union, Type

from itertools import chain

from .base import TableBase
from .preprocess import PreProcessorBase, NullPreProcessor, PreProcessorForTSTable
from ..runtime.transform import TransformLibrary, TransformLibraryForTSTable
from ..utils import chainable


class PrimaryTable(TableBase):
    TransformLibrary = TransformLibrary
    PreProcessorClass: Type[PreProcessorBase] = NullPreProcessor

    preprocessor = PreProcessorClass()

    def __init_subclass__(cls, **kwargs):
        super(PrimaryTable, cls).__init_subclass__(**kwargs)
        cls.preprocessor = cls.PreProcessorClass()

    def __init__(self, *args, pump, fields: Union[str, list[str]] = None, **kwargs):
        super(PrimaryTable, self).__init__(*args, **kwargs)
        self.pump = pump
        self.fields = fields
        self.init_fields = copy(fields)

    def calculate_field_dependencies(self):
        return []

    def get_tag(self, key: str):
        value = super(PrimaryTable, self).get_tag(key)
        if value is None:
            value = self.pump.all_values_for_tag(key)
        return value

    def get_data(self):
        data = self.pump.get_data(self, None if self.fields == "ALL" else self.fields)
        return self.preprocessor.preprocess(data, self.config, self.meta)

    def __repr__(self):
        return f"{self.__class__.__name__}" \
               f"(name:{self.name}, " \
               f"id:{id(self)}, " \
               f"field:{self.fields}, " \
               f"pump:{self.pump})"

    def mark_fields(self, *fields):
        if self.fields == "ALL":
            return
        orig_field = copy(self.fields)
        if fields:
            if "ALL" in fields:
                self.fields = "ALL"
            elif not self.fields:
                self.fields = list(fields)
            elif isinstance(self.fields, list):
                self.fields = list(set(self.fields) | set(fields))
            else:
                self.fields = list(set(fields) | {self.fields})
        if self.fields != orig_field:
            self.mark_dirty()

    @chainable
    def reset_fields(self):
        self.fields = copy(self.init_fields)
        self.mark_dirty()


class SecondaryTable(TableBase):
    TransformLibrary = TransformLibrary

    def __init__(self, *args, tf_method, tf_args, tf_kwargs, **kwargs):
        super(SecondaryTable, self).__init__(*args, **kwargs)
        self.tf_method = tf_method
        self.tf_args = tf_args
        self.tf_kwargs = tf_kwargs

    def get_data(self):
        return self.tf_method(*self.tf_args, **self.tf_kwargs)

    @property
    def parents(self) -> list["TableBase"]:
        return [arg
                for arg in chain(self.tf_args,
                                 self.tf_kwargs.values()
                                 )
                if isinstance(arg, TableBase)]

    def calculate_field_dependencies(self):
        yield from self.tf_method.calculate_field_dependencies(*self.tf_args, **self.tf_kwargs)

    def __repr__(self):
        return f"{self.__class__.__name__}" \
               f"(name:{self.name}, " \
               f"id:{id(self)}, " \
               f"parents:{[p.name or id(p) for p in self.parents]})"


class TimeSeriesPrimaryTable(PrimaryTable):
    TransformLibrary = TransformLibraryForTSTable
    PreProcessorClass = PreProcessorForTSTable
