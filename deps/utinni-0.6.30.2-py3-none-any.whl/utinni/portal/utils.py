import importlib
from pathlib import Path


def import_cookbook(loc):
    if ":" in loc:
        module_name, cb_name = loc.split(":")
    else:
        module_name, cb_name = loc, "make_context"
    path = (Path(Path.cwd(), module_name + ".py"))
    spec = importlib.util.spec_from_file_location(module_name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return path.stem, getattr(module, cb_name)
