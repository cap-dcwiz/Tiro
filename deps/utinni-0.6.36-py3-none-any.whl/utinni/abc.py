from abc import ABC, abstractmethod
from numbers import Number
from typing import Optional

import pandas as pd

from utinni.types import ValueType


class TableABC(ABC):
    @property
    @abstractmethod
    def value(self):
        pass
