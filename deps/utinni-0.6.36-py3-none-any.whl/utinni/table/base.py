from abc import abstractmethod
from typing import Type, Callable

import pandas as pd

from ..config import OverwrittenConfig
from ..exception import NoValidDataFoundException
from ..types import ValueType, guess_value_dimension
from ..utils import chainable
from ..abc import TableABC
from ..runtime.transform import TransformLibrary, tf_over_values


class TableBase(TableABC):
    TransformLibrary: Type[TransformLibrary] = TransformLibrary

    def __init__(self, context, meta: dict = None):
        super(TableBase, self).__init__()
        self.context = context
        self.name = None
        self.runtime = context.runtime  # Runtime

        self._data = None  # real data wrapped in the table

        # tags relates to the data in table, like the tags in TSDB.
        # They may need to be dynamically fetched from data source.
        self._tags = {}

        # meta relates to the table itself, like whether the table contains time-series data.
        self._meta = meta or {}

        # If the dirty flag does not match the runtime, the value needs to be re-calculated.
        self._dirty_flag = None

        self._local_config = {}

        self.transform_library = context.create_transform_library(TransformLibrary)

    @chainable
    def set_name(self, name: str):
        self.name = name

    @property
    def meta(self):
        return self._meta

    @chainable
    def set_meta(self, key: str, value):
        self._meta[key] = value

    @chainable
    def update_meta(self, **kwargs):
        self._meta.update(kwargs)

    def check_mate(self, key: str, expected_value) -> bool:
        return self._meta[key] == expected_value

    def get_tag(self, key: str):
        return self._tags.get(key, None)

    @chainable
    def set_tag(self, key: str, value):
        self._tags[key] = value

    @property
    def dimension(self) -> int:
        return guess_value_dimension(self.value)

    @chainable
    def mark_dirty(self):
        self._dirty_flag = None

    def is_dirty(self) -> bool:
        return self._dirty_flag != self.runtime.dirty_flag

    def primary_ancestors_and_fields(self):
        for primary_table, fields in self.runtime.dmngr.depended_primary_fields(self):
            yield primary_table, fields

    @abstractmethod
    def calculate_field_dependencies(self):
        ...

    @abstractmethod
    def get_data(self):
        pass

    @property
    def value(self):
        if self._data is None or self.is_dirty():
            self.runtime.revise_dependency_graph(self)
            self.runtime.mark_fields_for_table(self)
            try:
                self._data = self.get_data()
            except NoValidDataFoundException:
                raise
            except Exception as e:
                raise RuntimeError(*e.args)
            dim = guess_value_dimension(self._data)
            if dim == 1:
                self._data.name = self.name or self._data.name
            self._dirty_flag = self.runtime.dirty_flag
        return self._data

    @property
    def parents(self) -> list["TableBase"]:
        return list(self.runtime.dmngr.find_parents(self))

    @property
    def real_parents(self) -> set["TableBase"]:
        ps = set()
        for p in self.parents:
            if p.name is None:
                ps.update(p.real_parents)
            else:
                ps.add(p)
        return ps

    def overwrite_config(self, **kwargs):
        self._local_config |= kwargs

    @property
    def config(self):
        return OverwrittenConfig(self._local_config, self.pump.config)

    def plot(self, *args, **kwargs):
        """Plot in Jupyter"""
        return self.value.plot(*args, **kwargs)

    def plot_deps(self, **kwargs):
        return self.context.plot_deps(tables=[self], **kwargs)

    def __getattr__(self, item):
        transform = self.transform_library[item]
        if not transform:
            transform = tf_over_values(
                lambda x, *args, **kwargs: getattr(x, item)(*args, **kwargs)
            )
        return lambda *args, **kwargs: self.runtime.make_secondary_table(
            transform, self, *args, **kwargs
        )

    def __getitem__(self, item):
        transform = self.transform_library["extract"].partial(name=item)
        return self.runtime.make_secondary_table(transform, self)

    def apply_tf(self, func: Callable[..., ValueType], *args, **kwargs):
        return self.runtime.make_secondary_table(func, self, *args, **kwargs)

    def __init_subclass__(cls, **kwargs):
        cls.TransformLibrary.install_special_and_predefined_methods(cls)

    def is_time_series(self):
        dimension = self.dimension
        if dimension == 1 or dimension == 2:
            return isinstance(self.value.index, pd.DatetimeIndex)
        elif dimension == 3:
            return all(
                isinstance(v.index, pd.DatetimeIndex) for v in self.value.values()
            )
        else:
            return False
