from networkx import DiGraph

from ..abc import TableABC
from ..table.base import TableBase


class DependencyManager:
    def __init__(self):
        self.deps: dict[TableBase, dict[str, set[tuple[TableABC, str]]]] = {}

    def revise_dependency_graph(self, table: TableBase):
        # TODO: entity in self.deps may need recalculation in some situations
        if table not in self.deps:
            for (
                first_table,
                orig_field,
                ret_field,
            ) in table.calculate_field_dependencies():
                self.add_dependency(first_table, orig_field, table, ret_field)
                self.revise_dependency_graph(first_table)

    def add_dependency(self, first_table, first_field, second_table, second_field):
        deps = self.deps.get(second_table, {})
        dep_fields = deps.get(second_field, set())
        dep_fields.add((first_table, first_field))
        deps[second_field] = dep_fields
        self.deps[second_table] = deps

    def depended_primary_fields(self, table, *fields):
        self.revise_dependency_graph(table)
        deps = self.deps.get(table, {})
        if deps:
            if "ALL" in deps:
                for parent_table, parent_field in deps["ALL"]:
                    yield from self.depended_primary_fields(parent_table, parent_field)
            required_fields = (
                deps.keys() if "ALL" in fields else [f for f in fields if f in deps]
            )
            for field in required_fields:
                for parent_table, parent_field in deps[field]:
                    yield from self.depended_primary_fields(parent_table, parent_field)
        else:
            yield table, fields

    def find_parents(self, table):
        deps = self.deps.get(table, {})
        for item in deps.values():
            for parent, _ in item:
                yield parent

    def iter_parents(self, table, exclude_set, ignore_none):
        if table in exclude_set:
            return
        else:
            exclude_set.add(table)
        if ignore_none:
            parents = table.real_parents
        else:
            parents = table.parents
        for p in parents:
            yield p, table
            yield from self.iter_parents(p, exclude_set, ignore_none)

    def dependency_graph(self, tables, name_only, ignore_none):
        graph = DiGraph()
        exclude_set = set()
        ignore_none = ignore_none or name_only
        for table in tables:
            self.revise_dependency_graph(table)
        for table in tables:
            if table.name is None and ignore_none:
                continue
            for p, t in self.iter_parents(table, exclude_set, ignore_none):
                if name_only:
                    graph.add_edge(p.name, t.name)
                else:
                    graph.add_edge(p, t)
        return graph
