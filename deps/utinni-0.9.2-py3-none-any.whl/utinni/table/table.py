from copy import copy
from datetime import timedelta
from itertools import chain
from numbers import Number
from typing import Union, Type

from numpy import inf

from .base import TableBase, ErrorValue, ParentTableException
from .preprocess import PreProcessorBase, NullPreProcessor, PreProcessorForTSTable
from ..config import Configurable
from ..runtime.transform import TransformLibrary, TransformLibraryForTSTable
from ..utils import chainable


class PrimaryTable(TableBase, Configurable):
    TransformLibrary = TransformLibrary
    PreProcessorClass: Type[PreProcessorBase] = NullPreProcessor

    preprocessor = PreProcessorClass()

    def __init_subclass__(cls, **kwargs):
        super(PrimaryTable, cls).__init_subclass__(**kwargs)
        cls.preprocessor = cls.PreProcessorClass()

    def __init__(self, *args, pump, fields: Union[str, list[str]] = None, **kwargs):
        super(PrimaryTable, self).__init__(*args, config_parent=pump, **kwargs)
        self.pump = pump
        self.fields = fields
        self.init_fields = copy(fields)

    def calculate_field_dependencies(self):
        return []

    def get_tag(self, key: str):
        value = super(PrimaryTable, self).get_tag(key)
        if value is None:
            value = self.pump.all_values_for_tag(key)
        return value

    def get_data(self):
        if self.fields == "ALL":
            if self.init_fields:
                fields = self.init_fields
            else:
                fields = None
        else:
            fields = self.fields
        data = self.pump.get_data(self, fields)
        if fields is None:
            self.fields = "ALL"
        elif self.init_fields and fields == self.init_fields:
            self.fields = "ALL"
        return self.preprocessor(data, self.config, self.meta)

    def __repr__(self):
        return (
            f"{self.__class__.__name__}"
            f"(name:{self.name}, "
            f"id:{id(self)}, "
            f"field:{self.fields}, "
            f"pump:{self.pump})"
        )

    def mark_fields(self, *fields):
        if self.fields == "ALL":
            return
        orig_field = copy(self.fields)
        if fields:
            if "ALL" in fields:
                self.fields = "ALL"
            elif not self.fields:
                self.fields = list(fields)
            elif isinstance(self.fields, list):
                self.fields = list(set(self.fields) | set(fields))
            else:
                self.fields = list(set(fields) | {self.fields})
        if self.fields != orig_field:
            self.mark_dirty()

    @chainable
    def reset_fields(self):
        self.fields = copy(self.init_fields)
        self.mark_dirty()


class SecondaryTable(TableBase):
    TransformLibrary = TransformLibrary

    def __init__(self, *args, tf_method, tf_args, tf_kwargs, **kwargs):
        super(SecondaryTable, self).__init__(*args, **kwargs)
        self.tf_method = tf_method
        self.tf_args = tf_args
        self.tf_kwargs = tf_kwargs

    def get_data(self):
        if any(t.value is ErrorValue for t in chain(self.tf_args, self.tf_kwargs.values()) if isinstance(t, TableBase)):
            raise ParentTableException
        return self.tf_method(*self.tf_args, **self.tf_kwargs)

    def calculate_field_dependencies(self):
        yield from self.tf_method.calculate_field_dependencies(
            *self.tf_args, **self.tf_kwargs
        )

    def __repr__(self):
        return (
            f"{self.__class__.__name__}"
            f"(name:{self.name}, "
            f"id:{id(self)}, "
            f"parents:{[p.name or id(p) for p in self.parents]})"
        )


class TimeSeriesPrimaryTable(PrimaryTable):
    TransformLibrary = TransformLibraryForTSTable
    PreProcessorClass = PreProcessorForTSTable

    def config_items(self):
        yield from super(TimeSeriesPrimaryTable, self).config_items()
        yield "interpolate", None, None
        yield "interpolate_limit", None, None
        yield "interpolate_value_range", (-inf, inf), None
        yield "interpolate_fill_na", False, "Can be a number, False, bfill or ffill"
        yield (
            "interpolate_kwargs",
            dict(method="spline", order=3, limit_area="inside"),
            "Approach and kwargs for interpolation",
        )

    def extract_config(self, config: dict[str, ...]) -> dict[str, ...]:
        step = self.get_config_or_error(config, "step")
        interpolate_limit = self.get_config_or_error(config, "interpolate_limit")
        if isinstance(interpolate_limit, str) and interpolate_limit.endswith("s"):
            interpolate_limit = timedelta(seconds=float(interpolate_limit[:-1]))
        if isinstance(interpolate_limit, timedelta) and step:
            if isinstance(step, str):
                if "mo" in step or "MS" in step:
                    _step = timedelta(days=30 * float(step[:-2]))
                elif "M" in step:
                    _step = timedelta(days=30 * float(step[:-1]))
                else:
                    raise RuntimeError(f"Unrecognised step: {step}")
                interpolate_limit = interpolate_limit // _step
            elif isinstance(step, Number):
                interpolate_limit = interpolate_limit.total_seconds() // step
            else:
                interpolate_limit = interpolate_limit // step

        return dict(
            interpolate_limit=interpolate_limit,
        )
