class NoValidDataFoundException(RuntimeError):
    pass
