from copy import copy

from .utils import chainable


class ConfigDict(dict):
    def __getattr__(self, item):
        return self.get(item)


class Configurable:
    def __init__(self, *args, preconfig=None, config_parent=None, **kwargs):
        self.config_set = {}
        if preconfig:
            self.config_set |= preconfig
        self.config_parent = config_parent

    def set_config_parent(self, parent):
        self.config_parent = parent

    def get_config_or_error(self, config, name):
        if name in config:
            res = config[name]
            if res is not NotImplemented:
                return res
        raise ValueError(f"Config {name} is required for {self.__class__.__name__}")

    def config_items(self):
        return
        yield

    def extract_config(self, config):
        return config

    @chainable
    def bind(self, **kwargs):
        self.config_set |= kwargs

    @chainable
    def unbind(self, *args):
        for arg in args:
            del self.config_set[arg]

    def collect_default_config(self):
        default_config_set = {
            k: v for k, v, _ in self.config_items() if v is not NotImplemented
        }
        if self.config_parent:
            return self.config_parent.collect_default_config() | default_config_set
        else:
            return default_config_set

    def collect_config(self):
        if self.config_parent:
            return self.config_parent.collect_config() | self.config_set
        else:
            return copy(self.config_set)

    def process_config_wrapped(self, config):
        if self.config_parent:
            config = self.config_parent.process_config_wrapped(config)
        return config | self.extract_config(config)

    @property
    def config(self):
        config = self.collect_default_config() | self.collect_config()
        return ConfigDict(self.process_config_wrapped(config))
