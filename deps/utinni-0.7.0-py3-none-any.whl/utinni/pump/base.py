from abc import ABC, abstractmethod
from datetime import datetime, timedelta
from numbers import Number

from pytz import UTC

from ..config import Configurable
from ..types import ValueType
from ..utils import chainable


class DataPump(Configurable, ABC):
    def __init__(self, *args, **kwargs):
        super(DataPump, self).__init__(*args, **kwargs)
        self.context = None
        self.name = None

    @chainable
    def set_context(self, context):
        self.context = context
        self.set_config_parent(context)

    @chainable
    def set_name(self, name: str):
        self.name = name

    @abstractmethod
    def gen_table(self, *args, **kwargs):
        pass

    @abstractmethod
    def get_data(self, table, fields) -> ValueType:
        pass

    def all_values_for_tag(self, tag: str):
        return None

    def __repr__(self):
        return f"{self.name}_pump({self.__class__.__name__})"


class TimeSeriesDataPump(DataPump, ABC):
    def config_items(self):
        yield from super(TimeSeriesDataPump, self).config_items()
        yield "start", None, None
        yield "step", None, None
        yield "stop", None, None
        yield "timezone", "Asia/Singapore", "Timezone to use for start and stop"

    def extract_config(self, config: dict[str, ...]) -> dict[str, ...]:
        start = self.get_config_or_error(config, "start")
        stop = config.get("stop", None) or datetime.utcnow()
        step = self.get_config_or_error(config, "step")
        if isinstance(step, Number):
            step = timedelta(seconds=float(step))
        if isinstance(stop, timedelta):
            stop = start + stop
        if isinstance(start, timedelta):
            start = stop + start
        if start and start.tzinfo is None:
            start = start.replace(tzinfo=UTC)
        if stop and stop.tzinfo is None:
            stop = stop.replace(tzinfo=UTC)
        return dict(
            start=start,
            step=step,
            stop=stop,
        )
