from functools import partial

from .config import Configurable
from .runtime.runtime import Runtime
from .utils import chainable


class Context(Configurable):
    def __init__(self, clients=None, **kwargs):
        super(Context, self).__init__()
        self.runtime = Runtime(self)
        self.pumps = dict()
        self.transform_libraries = {}
        self.bind(**kwargs)
        self.clients = clients or {}

    def add_client(self, overwrite=False, **clients):
        for key, client in clients.items():
            if key not in self.clients or overwrite:
                self.clients[key] = client

    @chainable
    def add_pump(self, name, pump: Configurable):
        self.pumps[name] = pump.set_context(self).set_name(name)
        setattr(self, f"{name}_table", partial(self.table, name))
        setattr(self, f"{name}_pump", pump)

    @chainable
    def del_pump(self, name):
        del self.pumps[name]
        delattr(self, f"{name}_table")
        delattr(self, f"{name}_pump")

    def table(self, pump_name, *args, **kwargs):
        return self.pumps[pump_name].gen_table(*args, **kwargs)

    def create_transform_library(self, cls, *args, **kwargs):
        if cls not in self.transform_libraries:
            self.transform_libraries[cls] = cls(*args, **kwargs)
        return self.transform_libraries[cls]

    def __getattr__(self, item):
        if self.runtime.has_define(item):
            return self.runtime.get_define(item)
        else:
            res = getattr(self.runtime, item)
            if getattr(res, "__chainable__", False):

                def wrapped(*args, **kwargs):
                    res(*args, **kwargs)
                    return self

                return wrapped
            else:
                return res

    def clear(self):
        self.clear_def()
        for name in self.pumps:
            delattr(self, f"{name}_table")
            delattr(self, f"{name}_pump")
        self.pumps.clear()
        self.transform_libraries.clear()
        self.clients.clear()
        self.runtime = None

    def __iter__(self):
        yield from self.runtime
