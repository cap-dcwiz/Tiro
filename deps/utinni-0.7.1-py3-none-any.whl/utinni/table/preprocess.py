from abc import ABC
from datetime import datetime, timedelta
from numbers import Number
from typing import Union

import pandas as pd
from pandas.core.dtypes.common import is_numeric_dtype

from ..types import (
    ValueType,
    DFSType,
    Dim1ValueType,
    Dim2ValueType,
    Dim3ValueType,
    guess_value_dimension,
)
from ..utils import easy_interpolate


class PreProcessorBase(ABC):
    def __call__(self, value: ValueType, config, table_meta) -> ValueType:
        dim = guess_value_dimension(value)
        if dim < 0:
            preprocess_handler_name = "preprocess_dim_free"
        else:
            preprocess_handler_name = f"preprocess_dim_{dim}"
        preprocessor = getattr(self, preprocess_handler_name, None)
        if preprocessor:
            return preprocessor(value, config, table_meta)
        else:
            return value

    def preprocess_dim_3(
        self, value: Dim3ValueType, config, table_meta
    ) -> Dim3ValueType:
        preprocess_dim_2 = getattr(self, "preprocess_dim_2", None)
        if preprocess_dim_2:
            return {
                k: preprocess_dim_2(v, config, table_meta) for k, v in value.items()
            }
        else:
            return value


class NullPreProcessor(PreProcessorBase):
    pass


class PreProcessorForTSTable(PreProcessorBase):
    def align_time_index(
        self,
        df: DFSType,
        start: datetime,
        stop: datetime,
        step: timedelta,
        timezone: str,
    ) -> DFSType:
        idx = df.index
        idx_min = idx.min()
        idx_max = idx.max()
        if idx_min > start:
            idx = idx.union(pd.date_range(start, idx_min, freq=step))
        if idx_max < stop:
            idx = idx.union(pd.date_range(idx_max, stop, freq=step))
        df = df.reindex(idx)
        df.index = df.index.tz_convert(timezone)
        df = df.sort_index().resample(step, origin="start_day").last()
        return df

    @staticmethod
    def _test_if_can_interpolate(value) -> bool:
        dimension = guess_value_dimension(value)
        if dimension == 1:
            return is_numeric_dtype(value)
        elif dimension == 2:
            return all(is_numeric_dtype(x) for x in value.dtypes)
        else:
            raise RuntimeError(f"Wrong dimension: {dimension}")

    def preprocess_dim_1or2(
        self, value: Union[Dim1ValueType, Dim2ValueType], config, table_meta
    ) -> Union[Dim1ValueType, Dim2ValueType]:
        if config.step is not None:
            value = self.align_time_index(
                value, config.start, config.stop, config.step, timezone=config.timezone
            )
        else:
            if config.interpolate and isinstance(config.interpolate_limit, timedelta):
                raise RuntimeError(
                    "Step cannot be None while interpolate_limit is a timedelta."
                )
        if config.interpolate and config.interpolate_limit > 0:
            if self._test_if_can_interpolate(value):
                value = easy_interpolate(
                    value,
                    limit_direction="both",
                    limit=config.interpolate_limit,
                    min_value=config.interpolate_value_range[0],
                    max_value=config.interpolate_value_range[1],
                    **config.interpolate_kwargs or {},
                )
            fill_na = config.interpolate_fill_na
            if fill_na is not False:
                if isinstance(fill_na, Number):
                    value.fillna(fill_na, inplace=True)
                else:
                    value.fillna(method=fill_na, inplace=True)
        return value

    def preprocess_dim_1(self, *args, **kwargs):
        return self.preprocess_dim_1or2(*args, **kwargs)

    def preprocess_dim_2(self, *args, **kwargs):
        return self.preprocess_dim_1or2(*args, **kwargs)
