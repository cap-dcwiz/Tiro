import typer

from .router import router


def run():
    typer.run(router.make_entry())
